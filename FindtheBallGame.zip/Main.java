/** 
 * this class just redirects to Script for the main page
 * Line 3 2/4 classes
 * Line 10 Starts code redirection to Script.java
 */
import java.util.Scanner;
public class Main //2/4 classes
{
    public static void main(String[] args)
    {
        Script.intro();
        
    }
}